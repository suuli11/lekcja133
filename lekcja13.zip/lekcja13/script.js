$(document).ready(function () {

    $("#registerForm").validate({

        rules: {
            name: {
                required: true,
                minlength: 2
            },

            email: {
                required: true,
                email: true
            },

            password: {
                required: true,
                minlength: 6
            },

            confirmPassword: {
                required: true,
                equalTo: "#password"
            },

            age: {
                required: true,
                digits: true,
                min: 18
            }
        },

        messages: {
            name: {
                required: "Podaj imię.",
                minlength: "Imię musi mieć minimum 2 znaki."
            },

            email: {
                required: "Podaj adres e-mail.",
                email: "Wprowadź poprawny adres e-mail."
            },

            password: {
                required: "Podaj hasło.",
                minlength: "Hasło musi mieć minimum 6 znaków."
            },

            confirmPassword: {
                required: "Powtórz hasło.",
                equalTo: "Hasła muszą być identyczne."
            },

            age: {
                required: "Podaj wiek.",
                digits: "Wiek może zawierać tylko cyfry.",
                min: "Musisz mieć co najmniej 18 lat."
            }
        },

        submitHandler: function (form) {
            alert("Formularz poprawny!");
        }
        
    });

});