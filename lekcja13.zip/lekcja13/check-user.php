<?php

$existingUsers = [
    "admin",
    "test",
    "janek",
    "kasia"
];

$username = $_POST['username'];

if (in_array(strtolower($username), $existingUsers)) {
    echo "false";
} else {
    echo "true";
}